<?php
session_start();
require 'includes/database.php/pdo.php';

// Verifica si hay sesión iniciada
if (!isset($_SESSION['usuario_id'])) {
    header("Location: index.php");
    exit;
}

$usuario_id = $_SESSION['usuario_id'];
$mensaje = "";



// AGREGAR CONTACTO
if (isset($_POST['agregar'])) {
    $nombre = $_POST['nombre'];
    $telefono = $_POST['telefono'];
    $email = $_POST['email'];

    $consulta = $pdo->prepare("INSERT INTO contactos (usuario_id, nombre, telefono, email) VALUES (?, ?, ?, ?)");
    $consulta->execute([$usuario_id, $nombre, $telefono, $email]);
    $mensaje = "Contacto agregado correctamente.";


}

// EDITAR CONTACTO
if (isset($_POST['editar'])) {
    $id = $_POST['id'];
    $nombre = $_POST['nombre'];
    $telefono = $_POST['telefono'];
    $email = $_POST['email'];

    $consulta = $pdo->prepare("UPDATE contactos SET nombre = ?, telefono = ?, email = ? WHERE id = ? AND usuario_id = ?");
    $consulta->execute([$nombre, $telefono, $email, $id, $usuario_id]);
    $mensaje = "Contacto actualizado.";
}

// ELIMINAR CONTACTO
if (isset($_GET['eliminar'])) {
    $id = $_GET['eliminar'];
    $consulta = $pdo->prepare("DELETE FROM contactos WHERE id = ? AND usuario_id = ?");
    $consulta->execute([$id, $usuario_id]);
    $mensaje = "Contacto eliminado.";
}

// LISTAR CONTACTOS
$consulta = $pdo->prepare("SELECT * FROM contactos WHERE usuario_id = ?");
$consulta->execute([$usuario_id]);
$contactos = $consulta->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Mis Contactos</title>
</head>
<body>
    <h2>Bienvenido, <?= htmlspecialchars($_SESSION['nombre']) ?></h2>
    <?php if ($mensaje): ?>
        <p style="color:green;"><?= htmlspecialchars($mensaje) ?></p>
    <?php endif; ?>

    <p><a href="logout.php">Cerrar sesión</a></p>

    <h3>Agregar nuevo contacto</h3>
    <form method="post">
        <input type="text" name="nombre" placeholder="Nombre" required>
        <input type="text" name="telefono" placeholder="Teléfono">
        <input type="email" name="email" placeholder="Correo">
        <button type="submit" name="agregar">Agregar</button>
    </form>

    <h3>Lista de contactos</h3>
    <table border="1">
        <tr>
            <th>Nombre</th>
            <th>Teléfono</th>
            <th>Email</th>
            <th>Acciones</th>
        </tr>
        <?php foreach ($contactos as $contacto): ?>
            <tr>
                <form method="post">
                    <td><input type="text" name="nombre" value="<?= htmlspecialchars($contacto['nombre']) ?>"></td>
                    <td><input type="text" name="telefono" value="<?= htmlspecialchars($contacto['telefono']) ?>"></td>
                    <td><input type="email" name="email" value="<?= htmlspecialchars($contacto['email']) ?>"></td>
                    <td>
                        <input type="hidden" name="id" value="<?= $contacto['id'] ?>">
                        <button type="submit" name="editar">editar contacto</button>
                        
                        <a href="?eliminar=<?= $contacto['id'] ?>" onclick="return confirm('¿Eliminar este contacto?')">Eliminar</a>
                    </td>
                </form>
            </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>