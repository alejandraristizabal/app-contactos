<?php
session_start();

$servidor = "localhost";
$usuario = "root";
$password = "";
$base_datos = "contactos_app";

// Crear conexión
$conexion = new mysqli($servidor, $usuario, $password, $base_datos);

// Verificar conexión
if ($conexion->connect_error) {
    die("Conexión fallida: " . $conexion->connect_error);
}
echo "Conexión exitosa";



// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['usuario_id'])) {
    header("Location: index.php");
    exit;
}

$usuario_id = $_SESSION['usuario_id'];

// Consultar los contactos del usuario actual
$consulta = $conexion->prepare("SELECT * FROM contactos WHERE usuario_id = ?");
$consulta->bind_param("i", $usuario_id);
$consulta->execute();
$resultado = $consulta->get_result();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Mis Contactos</title>
</head>
<body>
    <h2>Bienvenido, <?= htmlspecialchars($_SESSION['nombre']) ?></h2>
    <h3>Lista de contactos</h3>

    <table border="1">
        <tr>
            <th>Nombre</th>
            <th>Teléfono</th>
            <th>Email</th>
        </tr>
        <?php while ($contacto = $resultado->fetch_assoc()): ?>
            <tr>
                <td><?= htmlspecialchars($contacto['nombre']) ?></td>
                <td><?= htmlspecialchars($contacto['telefono']) ?></td>
                <td><?= htmlspecialchars($contacto['email']) ?></td>
            </tr>
        <?php endwhile; ?>
    </table>

    <br>
    <a href="agregar">Agregar nuevo contacto</a>
</body>
</html>