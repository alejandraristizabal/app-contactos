
<?php
session_start();
require 'includes/database.php/pdo.php';

$mensaje = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // REGISTRO
    if (isset($_POST['registro'])) {
        $nombre = trim($_POST['nombre']);
        $email = trim($_POST['email']);
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

        // Verificar si ya existe el usuario
        $verificar = $pdo->prepare("SELECT id FROM usuarios WHERE email = ?");
        $verificar->execute([$email]);

        if ($verificar->fetch()) {
            $mensaje = "El correo ya está registrado.";
        } else {
            $registro = $pdo->prepare("INSERT INTO usuarios (nombre, email, password) VALUES (?, ?, ?)");
            $registro->execute([$nombre, $email, $password]);
            $mensaje = "Registro exitoso. Ahora puedes iniciar sesión.";
        }
    }

    // INICIAR SESIÓN
    if (isset($_POST['login'])) {
        $email = trim($_POST['email']);
        $password = $_POST['password'];

        $consulta = $pdo->prepare("SELECT id, nombre, password FROM usuarios WHERE email = ?");
        $consulta->execute([$email]);
        $usuario = $consulta->fetch();

        if ($usuario && password_verify($password, $usuario['password'])) {
            $_SESSION['usuario_id'] = $usuario['id'];
            $_SESSION['nombre'] = $usuario['nombre'];
            header("Location: funciones.php");
            exit;
        } else {
            $mensaje = "Usuario o contraseña incorrectos.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Inicio</title>
</head>
<body>
    <h2>Sistema de Contactos</h2>

    <?php if ($mensaje): ?>
        <p style="color: red;"><?= htmlspecialchars($mensaje) ?></p>
    <?php endif; ?>

    <h3>Iniciar sesión</h3>
    <form method="post">
        <input type="email" name="email" placeholder="Correo" required><br>
        <input type="password" name="password" placeholder="Contraseña" required><br>
        <button type="submit" name="login">Iniciar sesión</button>
    </form>

    <h3>Registrarse</h3>
    <form method="post">
        <input type="text" name="nombre" placeholder="Nombre" required><br>
        <input type="email" name="email" placeholder="Correo" required><br>
        <input type="password" name="password" placeholder="Contraseña" required><br>
        <button type="submit" name="registro">Registrarse</button>
    </form>
</body>
</html>