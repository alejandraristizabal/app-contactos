<?php

$servidor = "localhost";
$usuario = "root";
$password = "";
$base_datos = "contactos_app";

// Crear conexión
$conexion = new mysqli($servidor, $usuario, $password, $base_datos);

// Verificar conexión
if ($conexion->connect_error) {
    die("Conexión fallida: " . $conexion->connect_error);
}
echo "Conexión exitosa";

session_start(); 

$mensaje = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario = $_POST['usuario'];
    $password = $_POST['password'];

    // Preparar consulta
    $consulta = $conexion->prepare("SELECT id, nombre, password FROM usuarios WHERE nombre = ?");
    $consulta->bind_param("s", $usuario);
    $consulta->execute();
    $resultado = $consulta->get_result();
    $datos = $resultado->fetch_assoc();

    // Verificar contraseña
    if ($datos && password_verify($password, $datos['password'])) {
        $_SESSION['usuario_id'] = $datos['id'];
        $_SESSION['nombre'] = $datos['nombre'];
        header("Location: contactos.php");
        exit;
    } else {
        $mensaje = "Usuario o contraseña incorrectos, intente nuevamente";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Iniciar sesión</title>
</head>
<body>
    <h2>Iniciar sesión</h2>
    <?php if ($mensaje): ?>
        <p style="color:red;"><?= htmlspecialchars($mensaje) ?></p>
    <?php endif; ?>

    <form method="post">
        <label>Usuario:</label><br>
        <input type="text" name="usuario" required><br><br>

        <label>Contraseña:</label><br>
        <input type="password" name="password" required><br><br>

        <button type="submit">Ingresar</button>
    </form>
</body>
</html>